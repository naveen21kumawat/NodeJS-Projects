// src/App.jsx

import React from "react";
import PayPalCheckout from "./components/PayPalCheckout";

function App() {
  return <PayPalCheckout />;
}

export default App;
