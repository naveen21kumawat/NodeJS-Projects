// src/services/paypalService.js

const API_BASE = "http://localhost:5000/api/paypal";

export const createOrderAPI = async (amount) => {
  const res = await fetch(`${API_BASE}/create-order`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ amount }),
  });

  if (!res.ok) throw new Error("Failed to create PayPal order");
  return await res.json();
};

export const captureOrderAPI = async (orderID) => {
  const res = await fetch(`${API_BASE}/capture-order/${orderID}`, {
    method: "POST",
  });

  if (!res.ok) throw new Error("Failed to capture PayPal order");
  return await res.json();
};
