// src/components/PayPalCheckout.jsx

import React, { useState } from "react";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { createOrderAPI, captureOrderAPI } from "./services/paypalService";

const PayPalCheckout = ({ price = "9.99" }) => {
  const [showPayPal, setShowPayPal] = useState(false);

  const createOrder = async () => {
    const data = await createOrderAPI(price);
    return data.id;
  };

  const onApprove = async (data) => {
    const details = await captureOrderAPI(data.orderID);
    alert(`✅ Purchase completed by ${details.payer.name.given_name}`);
  };

  return (
    <div style={{ padding: "50px", maxWidth: "400px", margin: "auto" }}>
      <h2>🎓 Buy React Course - ${price}</h2>
      <p>Includes full video lectures, source code, and lifetime access.</p>

      {!showPayPal && (
        <button
          onClick={() => setShowPayPal(true)}
          style={{
            padding: "10px 20px",
            backgroundColor: "#0070ba",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            fontSize: "16px",
            cursor: "pointer",
            marginTop: "20px",
          }}
        >
          Buy Now
        </button>
      )}

      {showPayPal && (
        <div style={{ marginTop: "20px" }}>
          <PayPalScriptProvider
            options={{
              "client-id":  "AXAq8qr5pSGasHhbqCmFWU81tocAG0N66QTLIa6mW9GB-aPsvE-mubYjwQacQt3ZWww5Rke7eBlbnAXJ",
              currency: "USD",
            }}
          >
            <PayPalButtons
              style={{ layout: "vertical" }}
              createOrder={createOrder}
              onApprove={onApprove}
            />
          </PayPalScriptProvider>
        </div>
      )}
    </div>
  );
};

export default PayPalCheckout;
