const { getAccessToken, createPayPalOrder, capturePayPalOrder } = require("../services/paypalService");

exports.createOrder = async (req, res) => {
  try {
    const accessToken = await getAccessToken();
    const order = await createPayPalOrder(accessToken);
    res.json({ id: order.data.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.captureOrder = async (req, res) => {
  try {
    const { orderID } = req.params;
    const accessToken = await getAccessToken();
    const capture = await capturePayPalOrder(orderID, accessToken);
    res.json(capture.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
